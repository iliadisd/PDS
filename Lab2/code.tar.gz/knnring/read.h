#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *matFile=fopen(argv[1],"r");
		if (matFile == NULL)
		{
			printf("Couldnt open file\n");
			exit(1);
		}
		double num,temp;
		int i=0,j=0;
		if(numbered==1){
			while ( fscanf(matFile,"%lf",&num) !=EOF )
			{
				if(i%(d+1)!=0){
					X[j]=num;
					j++;
				}
				i++;
			}
		}else if(numbered==2){
			for(i=0; i<n; i++){
				fscanf(matFile,"%lf",&num);
				for(j=0; j<d; j++){
					if(fscanf(matFile," %lf:%lf",&temp,&num)==EOF) break;
					X[i*d+j]=num;
        		}
				fscanf(matFile,"%*[^\n]\n");
			}
		}else{
			for(int skip=0;skip<4;skip++){
				fscanf(matFile,"%*[^\n]\n");
			}
			for(i=0; i<n; i++){
				fscanf(matFile,"%lf",&num);
				for(j=0; j<d; j++){
					if(fscanf(matFile,",%lf",&num)==EOF) break;
					X[i*d+j]=num;
        		}
				fscanf(matFile,"%*[^\n]\n");
			}
		}
		fclose(matFile);
